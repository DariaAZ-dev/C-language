#ifndef LISTE_H
#define LISTE_H
#include <stdlib.h>
typedef int Data;
typedef struct SCell SCell;
typedef struct SList SList;

SList* ListCreate();
void ListDelete(SList *list);

unsigned int ListSize(SList *list);

SCell* ListAddBegin(SList *list, Data elem);
SCell* ListAddEnd(SList *list, Data elem);
SCell* ListAddBefore(SList *list, SCell *cell, Data elem);
SCell* ListAddAfter(SList *list, SCell *cell, Data elem);
void ListDeleteCell(SList *list, SCell *cell);
SCell* ListGetFirst(SList *list);
SCell* ListGetLast(SList *list);
SCell* ListGetPrev(SCell *cell);
SCell* ListGetNext(SCell *cell);
Data ListGetData(SCell *cell);

#endif /* LISTE_H */