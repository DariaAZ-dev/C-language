
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef int Data;
typedef struct SCell SCell;
typedef struct SList SList;

struct SCell{
Data Value;
SCell* next;
SCell * prev;
};

struct SList{
 SCell *Head;
 SCell *Tail;
 int len;
 int occupied;
};

SList* ListCreate(){
 SList* new=malloc(sizeof(SList));
 new->Head=NULL;
 new->Tail=NULL;
 new-> len=0;
 new->occupied=0;
 return new;
};
void ListDelete(SList *list){
    if (list){
    SCell* curr=list->Head;
    while(curr->next != NULL){
        free(curr->prev);
        curr=curr->next;
        free(curr->prev);
    };
    free(curr);
    free(list);};
};

unsigned int ListSize(SList *list){
    return list->len;
};
void bigger(SList*list){
    if(list->len==list->occupied){
        list=realloc(list, sizeof(list)*2);
        list->len*=2;
    };
};
SCell* ListAddBegin(SList *list, Data elem){
    if (list){
        SCell * new=malloc(sizeof(SCell));
    new->Value=elem;
    new->next=list->Head;
    new->prev=NULL;
    bigger(list);

    list->Head->prev=new;
    list->occupied++;
    return new;
    };
};
SCell* ListAddEnd(SList *list, Data elem){
    if (list){
    SCell * new=malloc(sizeof(SCell));
    new->Value=elem;
    new->prev=list->Tail;
    new->next=NULL;
    bigger(list);

    list->Tail->next=new;
    list->occupied++;
    return new;};
};
SCell* ListAddBefore(SList *list, SCell *cell, Data elem){
    if (list){
    SCell * new=malloc(sizeof(SCell));
    new->Value=elem;
    new->prev=cell->prev;
    new->next=cell;
    bigger(list);
    cell->prev=new;
    list->occupied++;
    return new;};
};
SCell* ListAddAfter(SList *list, SCell *cell, Data elem){
    if (list){
    SCell * new=malloc(sizeof(SCell));
    new->Value=elem;
    new->prev=cell;
    new->next=cell->next;
    bigger(list);
    cell->next=new;
    list->occupied++;
    return new;};
}
;
void ListDeleteCell(SList *list, SCell *cell){
    if (list){
    cell->prev->next=cell->next;
    cell->next->prev=cell->prev;
    free(cell);
    list->occupied-=1;};
};

SCell* ListGetFirst(SList *list){
    return list->Head;
};
SCell* ListGetLast(SList *list){
    return list->Tail;
};
SCell* ListGetPrev(SCell *cell){
    return cell->prev;
};
SCell* ListGetNext(SCell *cell){
    return cell->next;
};
Data ListGetData(SCell *cell){
    return cell->Value;
};

