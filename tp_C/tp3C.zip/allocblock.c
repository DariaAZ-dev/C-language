
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef int Data;
typedef struct SCell SCell;
typedef struct SList SList;

struct SCell{
Data Value;
SCell* next;
SCell * prev;
};

struct SList{
 SCell *Head;
 SCell *Tail;
 int len;
};

SList* ListCreate(){
 SList* new=malloc(sizeof(SList));
 new->Head=NULL;
 new->Tail=NULL;
 new-> len=0;
 return new;
};
void ListDelete(SList *list){
    if (list){
    SCell* curr=list->Head;
    while (curr != NULL) {
        SCell *next = curr->next;
        free(curr);
        curr = next;
    };
    free(list);
};
};
unsigned int ListSize(SList *list){
    return list->len;
};
SCell* ListAddBegin(SList *list, Data elem){
    if (list){
    SCell * new=malloc(sizeof(SCell));
    if (!new) return NULL;
    new->Value=elem;
    new->next=list->Head;
    new->prev=NULL;

    if (list->Head == NULL) {
        // The list was empty: this new cell is also the Tail
        list->Tail = new;
    } else {
        // The list had elements: the old Head now points back to the new one
        list->Head->prev = new;
    };list->Head = new;
    list->len++;
    return new;
    };
    return NULL;
};
SCell* ListAddEnd(SList *list, Data elem){
    if (list){
    SCell * new=malloc(sizeof(SCell));
    new->Value=elem;
    new->prev=list->Tail;
    new->next=NULL;

    if (list->Tail == NULL) {
        // The list was empty: this new cell is also the Head
        list->Head = new;
    } else {
        // The list had elements: the old Tail now points forward to the new one
        list->Tail->next = new;
    };list->Tail = new;
    list->len++;
    return new;
};return NULL;};

SCell* ListAddBefore(SList *list, SCell *cell, Data elem){
    if (list){
    SCell * new=malloc(sizeof(SCell));
    new->Value=elem;
    if(cell->prev==NULL){
        cell->prev=new;
        list->Head=new;
        new->prev=cell->prev;
        new->next=cell;
    }else{
        new->prev=cell->prev;
        new->next=cell;
        cell->prev=new;
        cell->prev->next = new;
    };
    cell->prev=new;
    list->len++;
    return new;};return NULL;
};
SCell* ListAddAfter(SList *list, SCell *cell, Data elem){
    if (list){
    SCell * new=malloc(sizeof(SCell));
    new->Value=elem;
    if(cell->next==NULL){
        new->prev=cell;
    new->next=cell->next;
    cell->next=new;
    list->Tail=new;
    }else{
    new->prev=cell;
    new->next=cell->next;
    cell->next=new;
    cell->next->prev = new;
    };
    list->len++;
    return new;};return NULL;
};
void ListDeleteCell(SList *list, SCell *cell){
    if (list){
    cell->prev->next=cell->next;
    cell->next->prev=cell->prev;
    free(cell);
list->len--;};
};

SCell* ListGetFirst(SList *list){
    return list->Head;
};
SCell* ListGetLast(SList *list){
    return list->Tail;
};
SCell* ListGetPrev(SCell *cell){
    return cell->prev;
};
SCell* ListGetNext(SCell *cell){
    return cell->next;
};
Data ListGetData(SCell *cell){
    return cell->Value;
};