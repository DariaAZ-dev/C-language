#pragma once

#include "liste.h"

void PrintList(SList *list);

void TestListeVide();
void TestAjoutDebut();
void TestAjoutFin();
void TestAjoutApres();
void TestAjoutAvant();
void TestSupression();
void TestAleatoire();
