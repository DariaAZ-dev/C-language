#include "test.h"
#include <stdlib.h>
#include <time.h>

int main()
{
	srand(time(NULL));

	TestListeVide();
	TestAjoutDebut();
	TestAjoutFin();
	TestAjoutApres();
	TestAjoutAvant();
	TestSupression();
	TestAleatoire();

	return 0;
}
