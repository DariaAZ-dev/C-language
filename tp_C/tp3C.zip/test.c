#include "test.h"
#include <stdio.h>
#include <stdlib.h>

void PrintList(SList *list)
{
	if (list)
	{
		SCell *cell;

		printf("List (%d):\t", ListSize(list));
		cell=ListGetFirst(list);
		while (cell!=NULL)
		{
			printf("[%d] -> ", ListGetData(cell));
			cell=ListGetNext(cell);
		}
		printf("NULL\n");

		printf("Rev (%d):\t", ListSize(list));
		cell=ListGetLast(list);
		while (cell!=NULL)
		{
			printf("[%d] -> ", ListGetData(cell));
			cell=ListGetPrev(cell);
		}
		printf("NULL\n");
	}
}

int CheckList(SList *list)
{
	unsigned int nb = ListSize(list);
	SCell *cell = ListGetFirst(list);
	SCell *prev = NULL;
	int error = 0;
	unsigned int i = 0;

	while (!error && (cell != NULL))
	{
		if (prev != ListGetPrev(cell))
		{
			printf("Erreur : les liens de la liste sont inconsistants (noeud #%d : val=%d)\n", i, ListGetData(cell));
			error = 1;
		}
		else
		{
			prev = cell;
			cell = ListGetNext(cell);
			i++;
		}
	}

	if (!error && (i != nb))
	{
		printf("Erreur : la taille de la liste n'est pas consistante\n");
		error = 1;
	}

	return !error;
}

void TestListeVide()
{
	printf("Test liste vide\n- (res: NULL)\n");
	SList *list=ListCreate();
	PrintList(list);
	ListDelete(list);

	printf("\n");
}

void TestAjoutDebut()
{
	printf("Test ajout début\n- AddBegin 1, 2, 3 (res: 3 -> 2 -> 1 -> NULL)\n");
	SList *list=ListCreate();
	ListAddBegin(list, 1);
	ListAddBegin(list, 2);
	ListAddBegin(list, 3);
	CheckList(list);
	PrintList(list);
	ListDelete(list);

	printf("\n");
}

void TestAjoutFin()
{
	printf("Test ajout fin\n- AddEnd 1, 2, 3 (res: 1 -> 2 -> 3 -> NULL)\n");
	SList *list=ListCreate();
	ListAddEnd(list, 1);
	ListAddEnd(list, 2);
	ListAddEnd(list, 3);
	CheckList(list);
	PrintList(list);
	ListDelete(list);

	printf("\n");
}

void TestAjoutApres()
{
	printf("Test ajout après\n- AddAfter (1,NULL), (2,1), (3,1), (4,2) (res: 1 -> 3 -> 2 -> 4 -> NULL)\n");
	SList *list=ListCreate();
	SCell *c1=ListAddAfter(list, ListGetFirst(list), 1);
	SCell *c2=ListAddAfter(list, c1, 2);
	ListAddAfter(list, c1, 3);
	ListAddAfter(list, c2, 4);
	CheckList(list);
	PrintList(list);
	ListDelete(list);

	printf("\n");
}

void TestAjoutAvant()
{
	printf("Test ajout avant\n- AddBefore (1,NULL), (2,1), (3,1), (4,2) (res: 4 -> 2 -> 3 -> 1 -> NULL)\n");
	SList *list=ListCreate();
	SCell *c1=ListAddBefore(list, ListGetFirst(list), 1);
	SCell *c2=ListAddBefore(list, c1, 2);
	ListAddBefore(list, c1, 3);
	ListAddBefore(list, c2, 4);
	CheckList(list);
	PrintList(list);
	ListDelete(list);

	printf("\n");
}

void TestSupression()
{
	printf("Test supression\n");
	SList *list=ListCreate();

	printf("- AddEnd 1, 2, 3 Delete 2 (res: 1 -> 3 -> NULL)\n");
	SCell *c1=ListAddEnd(list, 1);
	SCell *c2=ListAddEnd(list, 2);
	SCell *c3=ListAddEnd(list, 3);
	ListDeleteCell(list, c2);
	CheckList(list);
	PrintList(list);

	printf("- Delete 3 (res: 1 -> NULL)\n");
	ListDeleteCell(list, c3);
	CheckList(list);
	PrintList(list);

	printf("- AddBegin 4 (res: 4 -> 1 -> NULL)\n");
	SCell *c4=ListAddBegin(list, 4);
	CheckList(list);
	PrintList(list);

	printf("- Delete 1, 4 (res: NULL)\n");
	ListDeleteCell(list, c1);
	ListDeleteCell(list, c4);
	CheckList(list);
	PrintList(list);

	ListDelete(list);

	printf("\n");
}

void TestAleatoire()
{
	printf("Test aléatoire\n");
	SList *list=ListCreate();

	printf("Ordre: ");
	unsigned int id=1;
	for (unsigned int i=0; i<100; ++i)
	{
		if (i) printf(", ");

		int proba=rand()%101;
		if (proba<10 && ListSize(list)>0)
		{
			int nb=ListSize(list)>1 ? rand()%(ListSize(list)-1) : 0;
			SCell *cell;
			unsigned int pos;
			for (cell=ListGetFirst(list),pos=0; pos<nb && cell!=NULL; ++pos) cell=ListGetNext(cell);
			if (cell)
			{
				printf("D(%d)", ListGetData(cell));
				ListDeleteCell(list, cell);
			}
		}
		else if (proba<10+30 && ListSize(list)>0)
		{
			int nb=ListSize(list)>1 ? rand()%(ListSize(list)-1) : 0;
			SCell *cell;
			unsigned int pos;
			for (cell=ListGetFirst(list),pos=0; pos<nb && cell!=NULL; ++pos) cell=ListGetNext(cell);
			if (cell)
			{
				printf("AA(%d,%d)", id, ListGetData(cell));
				ListAddAfter(list, cell, id++);
			}
		}
		else if (proba<40+30)
		{
			printf("AB(%d)", id);
			ListAddBegin(list, id++);
		}
		else
		{
			printf("AE(%d)", id);
			ListAddEnd(list, id++);
		}
	}
	printf("\n");
	CheckList(list);
	PrintList(list);

	ListDelete(list);

	printf("\n");
}
